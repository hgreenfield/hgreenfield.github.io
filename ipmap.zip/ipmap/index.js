function getIP(json) {
    console.log("My public IP address is: ", json.ip);
  }

//map overhead view- satellite
function initialize() {
       var fenway = {lat: 42.345573, lng: -71.098326};
      //  test: when no street view:
      //  var fenway = {lat: 39.139457, lng: 126.412032};
       var map = new google.maps.Map(document.getElementById('map'), {
         center: fenway,
         zoom: 20
       });
       var panorama = new google.maps.StreetViewPanorama(
           document.getElementById('pano'), {
             position: fenway,
             pov: {
               heading: 34,
               pitch: 10
             }
           });
          //  map.setStreetView(panorama);
          console.log(google.maps.StreetViewStatus.status);
           if (google.maps.StreetViewStatus === "OK") {
             map.setStreetView(panorama);
           } else {
             console.log('error status')
           }
       }
//map view with no imagery:
      // function initialize() {
      //   var fenway = {lat: 39.307522, lng:-76.621623};
      //   var map = new google.maps.Map(document.getElementById('map'), {
      //     center: fenway,
      //     zoom: 14
      //   });
      //   var panorama = new google.maps.StreetViewPanorama(
      //       document.getElementById('pano'), {
      //         position: fenway,
      //         pov: {
      //           heading: 34,
      //           pitch: 10
      //         }
      //       });
      //   map.setStreetView(panorama);
      // }
